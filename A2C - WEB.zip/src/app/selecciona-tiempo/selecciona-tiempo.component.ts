import { Component } from '@angular/core';

@Component({
  selector: 'app-selecciona-tiempo',
  templateUrl: './selecciona-tiempo.component.html',
  styleUrls: ['./selecciona-tiempo.component.css']
})
export class SeleccionaTiempoComponent {

}
