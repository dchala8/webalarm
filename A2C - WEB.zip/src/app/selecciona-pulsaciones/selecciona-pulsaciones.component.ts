import { Component } from '@angular/core';

@Component({
  selector: 'app-selecciona-pulsaciones',
  templateUrl: './selecciona-pulsaciones.component.html',
  styleUrls: ['./selecciona-pulsaciones.component.css']
})
export class SeleccionaPulsacionesComponent {

}
