import { Component } from '@angular/core';

@Component({
  selector: 'app-enlazar-dispositivo',
  templateUrl: './enlazar-dispositivo.component.html',
  styleUrls: ['./enlazar-dispositivo.component.css']
})
export class EnlazarDispositivoComponent {

}
