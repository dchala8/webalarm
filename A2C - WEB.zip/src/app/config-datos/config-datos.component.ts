import { Component } from '@angular/core';

@Component({
  selector: 'app-config-datos',
  templateUrl: './config-datos.component.html',
  styleUrls: ['./config-datos.component.css']
})
export class ConfigDatosComponent {

}
