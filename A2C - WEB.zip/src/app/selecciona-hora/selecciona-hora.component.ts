import { Component } from '@angular/core';

@Component({
  selector: 'app-selecciona-hora',
  templateUrl: './selecciona-hora.component.html',
  styleUrls: ['./selecciona-hora.component.css']
})
export class SeleccionaHoraComponent {

}
